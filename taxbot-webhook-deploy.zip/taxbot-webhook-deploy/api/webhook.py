from flask import Flask, request, jsonify, abort

app = Flask(__name__)

# 🔐 Mã bảo mật đơn giản
SECRET_TOKEN = "taxbot-2025-secret"

@app.route('/', methods=['POST'])
def handle_webhook():
    auth_header = request.headers.get("Authorization")
    if auth_header != f"Bearer {SECRET_TOKEN}":
        abort(403)

    data = request.json
    print("📥 Dữ liệu nhận được:", data)
    return jsonify({
        "status": "success",
        "message": "✅ Webhook đã nhận dữ liệu OK"
    }), 200

# ✅ Đoạn này dành cho test cục bộ
if __name__ == '__main__':
    app.run()
